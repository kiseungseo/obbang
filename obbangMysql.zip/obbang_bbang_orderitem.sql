-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: obbang
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bbang_orderitem`
--

DROP TABLE IF EXISTS `bbang_orderitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bbang_orderitem` (
  `orderItem_id` int NOT NULL AUTO_INCREMENT,
  `order_id` varchar(50) DEFAULT NULL,
  `menu_id` int DEFAULT NULL,
  `menuCount` int NOT NULL,
  `menu_price` int NOT NULL,
  `menuDiscount` int NOT NULL,
  `savePoint` int NOT NULL,
  PRIMARY KEY (`orderItem_id`),
  KEY `bbang_orderitem_ibfk_2` (`menu_id`),
  KEY `bbang_orderitem_ibfk_1` (`order_id`),
  CONSTRAINT `bbang_orderitem_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `bbang_order` (`order_id`) ON DELETE CASCADE,
  CONSTRAINT `bbang_orderitem_ibfk_2` FOREIGN KEY (`menu_id`) REFERENCES `menu` (`menu_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbang_orderitem`
--

LOCK TABLES `bbang_orderitem` WRITE;
/*!40000 ALTER TABLE `bbang_orderitem` DISABLE KEYS */;
INSERT INTO `bbang_orderitem` VALUES (44,'관리자1_2023042738',73,4,68000,0,0),(45,'관리자1_2023042738',74,1,5200,0,0),(46,'관리자1_2023042738',146,2,3000,0,0),(47,'관리자1_2023042738',151,2,6200,0,0),(48,'user1_2023042739',81,5,3000,0,0),(49,'관리자1_2023042740',186,1,3500,0,0),(50,'관리자1_2023042742',180,1,4000,0,0);
/*!40000 ALTER TABLE `bbang_orderitem` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-07 19:18:50
